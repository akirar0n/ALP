/*Autor: Roney Vila*/

package br.com.controle;

public class ConsultaRegistro {
    private int codigo;
    private int codpet;
    private float valor;
    private String dataconsulta;

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public int getCodpet() {
        return codpet;
    }

    public void setCodpet(int codpet) {
        this.codpet = codpet;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public String getDataconsulta() {
        return dataconsulta;
    }

    public void setDataconsulta(String dataconsulta) {
        this.dataconsulta = dataconsulta;
    }
    
    
}
